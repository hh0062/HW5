//40223026
//hadiehzahra habibi

#include  <stdio.h>

int main()
{
    int n;
    printf("enter number of elements:\n");
    scanf("%d",&n);

    char string1[n + 1];
    printf("enter string:\n");
    scanf("%s",string1);


    int counter = 0;

    for(int i = 0 ; string1[i] != '\0' ;)
    {
        if (string1[i] == string1[i + 1])
        {
            ++counter ;
            for(int j = i ; string1[j] != '\0' ; j++)
            {
                if(j < n - (2 * counter))
                    string1[j] = string1[j + 2];
                
                else
                    string1[j] = '\0' ;
            }

            printf("%s\n" , string1);

            i = 0;
        }

        else
            i++;

    }

    return 0;
}