//40223036
//hadiehzahra habibi

#include <stdio.h>
#include <string.h>
#include <ctype.h>

struct word
{
    char lan1[15];
    char lan2[15];
};

int main()
{
    int n;
    printf("enter n:\n");
    scanf("%d",&n);

    struct word array[n];

    for(int i = 0 ; i < n ; i++)
    {
        printf("enter word %d in both languages:\n",i + 1);
        scanf("%s %s",&array[i].lan1,&array[i].lan2);
    }

    char string[120];
    char temp;
    printf("enter string with space after each word(and after the last word):\n");
    scanf("%c",&temp);
    fgets(string ,120 ,stdin);

    if(islower(array[0].lan1[0]))
    {
        for(int i = 0 ; string[i] != '\0' ; i++)
            string[i] = tolower(string[i]);
    }
    else
    {
        for(int i = 0 ; string[i] != '\0' ; i++)
            string[i] = toupper(string[i]);
    }


    char *word = strtok(string , " ");

    while(word != NULL)
    {
        for(int i = 0 ; i < n ; i++)
        {
            if(!strcmp(word , array[i].lan1) || !strcmp(word , array[i].lan2))
            {
                if(strlen(array[i].lan1) < strlen(array[i].lan2))
                    printf("%s ", array[i].lan1);
                else
                    printf("%s " , array[i].lan2);
            }
        }

        word = strtok(NULL , " ");
    }

    return 0 ;
}